# Changelog - Phishing Defender

## [0.8.0-test] - 2025-10-18
### ✨ Added
- Komplett neues modernes Design für alle Screens
- Animierte Hintergründe
- Background Music System
- Settings Dialog
- Custom Feedback-System

### 🎨 Improved
- Alle Screens neu designt
- Buttons mit Hover-Effekten
- Bessere Farben & Schatten

### 🔧 Fixed
- Result Screen Button-Logik bei Level 3
- Fenster-Größe Probleme

### 📝 Notes
- Testversion für Uni-Projekt
- Siehe TODO.md für offene Punkte

---

## [0.5.0] - 2025-XX-XX
### ✨ Added
- Basis-Gameplay
- 3 Level
- Email-Datenbank
- Highscore-System

---

## [0.1.0] - 2025-XX-XX
### ✨ Added
- Initiales Projekt-Setup
